<!DOCTYPE html>
<html lang="en">

<head>
    <base href="../../">
    <title>File A Trademark Now | Trademark Assured</title>
    <?php include("../../backend/connectiondb.php"); ?>
    <?php include '../../includes/var.php'; ?>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <?php include '../../includes/styles.php'; ?>
</head>

<style scoped>
    @media only screen and (max-width: 1400px) {
        .landingPage h2 span {
            font-size: 34px;
        }

        .landingPage h2 {
            font-size: 1.7rem;
        }

        .landingPage .baner-girl {
            display: none;
        }

        .landingPage .listStyle p {
            font-size: 14px;
        }
    }

    @media only screen and (max-width: 1199px) {
        .landingPage h2 {
            font-size: 2rem;
        }

        .landingPage .listStyle {
            margin-bottom: 1.5rem;
        }

        .landingPage {
            height: 910px;
        }

        .mainSlider.landingPage {
            height: 900px;
        }

        .landingPage .leadForm .subTitle h5 {
            letter-spacing: 8px;
        }
    }

    @media only screen and (max-width: 991px) {

        .landingPage {
            height: 950px;
        }
    }

    @media only screen and (max-width: 767px) {
        .landheading {
            font-size: 2.5rem;
        }

        .landingPage p {
            color: #ccc;
            font-size: 14px;
            width: 100%;
        }

        .landingPage .listStyle p,
        .landingPage .listStyle p span,
        .landingPage p a {
            color: #ccc;
            font-size: 14px;
        }

        .landingPage p a {
            color: var(--yellow);
            text-decoration: underline;
        }

        .landingPage .listStyle i {
            font-size: 14px;
        }

        .landingPage h2 {
            margin-top: 3rem;
        }

        .mainSlider.landingPage {
            padding: 4rem 0 0rem;
            height: auto;
        }

        .mainSlider.landingPage {
            background: #170926;
        }

        .mainSlider.landingPage .btnStyle-yellow,
        .mainSlider.landingPage .btnStyle-yellow-border {
            display: block;
            text-align: center;
        }
    }

    @media only screen and (max-width: 575px) {
        .landingPage {
            height: 1160px;
        }

        .landingPage h2 {
            font-size: 1rem;
        }

        .landingPage h2 span {
            font-size: 28px;
            line-height: 44px;
        }

        .landingPage {
            height: 1070px;
        }

        .landingPage .leadForm .title h4 {
            font-size: 1rem;
        }

        .landingPage .leadForm .subTitle h5 {
            letter-spacing: 3px;
        }
    }
</style>
<?php
$taxUS = 0;
$taxUK = 0;
$taxEU = 0;
$silverpriceUS = 0;
$goldpriceUS = 0;
$diamondpriceUS = 0;
$silverpriceUK = 0;
$goldpriceUK = 0;
$diamondpriceUK = 0;
$silverpriceEU = 0;
$goldpriceEU = 0;
$diamondpriceEU = 0;

$silverpriceUSCur = 0;
$goldpriceUSCur = 0;
$diamondpriceUSCur = 0;
$silverpriceUKCur = 0;
$goldpriceUKCur = 0;
$diamondpriceUKCur = 0;
$silverpriceEUCur = 0;
$goldpriceEUCur = 0;
$diamondpriceEUCur = 0;

//silver Package Price US
$query = "select t1." . $common19 . ",t1." . $common13 . ",t1." . $table31Col1 . ",t2." . $table21Col1 . ",SUM(t1." . $table20Col1 . ") as " . $table20Col1 . ",t3." . $table31Col1 . " as tax1
        from " . $table31 . " t1
        inner join " . $table21 . " t2 on t1." . $common14 . " = t2." . $common2 . "
        inner join " . $table32 . " t3 on t3." . $common2 . " = t1." . $common19 . "
        where t1." . $common7 . "='1' and t1." . $table31Col1 . " = '1'
        GROUP BY t1." . $common19 . ",t1." . $common13 . "
    ";
$vacancies = mysqli_query($con, $query);
if ($vacancies->num_rows > 0) {
    while ($item = mysqli_fetch_assoc($vacancies)) {
        $temp = (float)$item["price"];
        // if($item[$table31Col1] == "1"){              // For Taxation open this comment 
        //    $temp = $temp + (($temp * $taxUS)/100);
        // }
        if ($item[$common19] == 1 && $item[$common13] == 1) {
            $silverpriceUSCur = $item[$table21Col1];
            $silverpriceUS = $temp;
        } else if ($item[$common19] == 1 && $item[$common13] == 2) {
            $goldpriceUSCur = $item[$table21Col1];
            $goldpriceUS = $temp;
        } else if ($item[$common19] == 1 && $item[$common13] == 3) {
            $diamondpriceUSCur = $item[$table21Col1];
            $diamondpriceUS = $temp;
        } else if ($item[$common19] == 2 && $item[$common13] == 1) {
            $silverpriceUKCur = $item[$table21Col1];
            $silverpriceUK =  $temp;
        } else if ($item[$common19] == 2 && $item[$common13] == 2) {
            $goldpriceUKCur = $item[$table21Col1];
            $goldpriceUK =  $temp;
        } else if ($item[$common19] == 2 && $item[$common13] == 3) {
            $diamondpriceUKCur = $item[$table21Col1];
            $diamondpriceUK = $temp;
        } else if ($item[$common19] == 3 && $item[$common13] == 1) {
            $silverpriceEUCur = $item[$table21Col1];
            $silverpriceEU = $temp;
        } else if ($item[$common19] == 3 && $item[$common13] == 2) {
            $goldpriceEUCur = $item[$table21Col1];
            $goldpriceEU = $temp;
        } else if ($item[$common19] == 3 && $item[$common13] == 3) {
            $diamondpriceEUCur = $item[$table21Col1];
            $diamondpriceEU = $temp;
        }
    }
}
?>

<body>

    <!--  ClickCease.com tracking-->
    <script type='text/javascript'>
        var script = document.createElement('script');
        script.async = true;
        script.type = 'text/javascript';
        var target = 'https://www.clickcease.com/monitor/stat.js';
        script.src = target;
        var elem = document.head;
        elem.appendChild(script);
    </script>
    <noscript>
        <a href='https://www.clickcease.com' rel='nofollow'><img src='https://monitor.clickcease.com' alt='ClickCease' /></a>
    </noscript>
    <!--  ClickCease.com tracking-->

    <header class="landingNav">
        <div class="topRow">
            <div class="container">
                <div class="row justify-content-end">
                    <div class="col-lg-6 col-md-8">
                        <ul class="contInfo">
                            <li><a href="mailto:<?= $email ?>"><i class="fa fa-envelope"></i>
                                    <?= $email ?>
                                </a></li>
                            <li><a href="tel:<?= $phone ?>"><i class="fa fa-phone fa-flip-horizontal"></i>
                                    <?= $phone ?>
                                </a></li>
                            <li><a href="javascript:void(0);" onclick="openChatWidget()"><i class="fa fa-comment-dots"></i> Consult An Expert</a></li>
                        </ul>
                    </div>
                    <!-- <div class="col-md-4 col-lg-6">
                        <ul class="socialList">
                            <li><a href="https://www.facebook.com/TrademarkAssured/" target="_blank"><i
                                        class="fab fa-facebook-f"></i></a></li>
                            <li><a href="https://www.instagram.com/trademarkaasured/" target="_blank"><i
                                        class="fab fa-instagram"></i></a></li>
                            <li><a href="https://twitter.com/TMAssured" target="_blank"><i
                                        class="fab fa-twitter"></i></a></li>
                            <li><a href="https://www.linkedin.com/company/trademark-assured/" target="_blank"><i
                                        class="fab fa-linkedin"></i></a></li>
                            <li><a href="https://www.youtube.com/@TrademarkAssured/about" target="_blank"><i
                                        class="fab fa-youtube"></i></a></li>
                        </ul>
                    </div> -->
                </div>
            </div>
        </div>
        <div class="nav-landing">
            <div class="container">
                <div class="row justify-content-between">
                    <div class="col-md-12">
                        <ul>
                            <li><img src="assets/images/land-logo.webp" class="img-fluid" alt="logo" width="362" height="33"></li>
                            <!-- <li><a href="tel:<?= $phone ?>"><i class="fa fa-phone-square"></i></a></li> -->
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="mainSlider landingPage">
        <div class="container">
            <div class="row align-items-center justify-content-between">
                <div class="col-xl-6 col-lg-6">
                    <h1 class="white-clr landheading">File A Trade Mark USPTO @ <span class="yellow-clr">$35!</span></h1>
                    <p>At Trademark Assured, our expert attorneys assist you trademark business name, logo, & slogan in USA @35$. File your trademark today chat now.</p>
                    <ul class="listStyle">
                        <li>
                            <i class="fa fa-check-square"></i>
                            <p>Trust the Legal Process With <span>Expert US Attorneys</span></p>
                        </li>
                        <li>
                            <i class="fa fa-check-square"></i>
                            <p><span>100% Approval</span> With Our Foolproof Process</p>
                        </li>
                        <li>
                            <i class="fa fa-check-square"></i>
                            <p><span>Get 24/7 Assistance</span> For All Your Urgent Needs</p>
                        </li>
                        <li>
                            <i class="fa fa-check-square"></i>
                            <p>Get Serial Number for Your Trademark Within <span>1-2 Business Days</span></p>
                        </li>
                    </ul>
                    <a href="sequence/step1" class="btnStyle-yellow mt-5 me-3">Apply For Your Trademark</a>
                    <a href="javascript:void(0);" onclick="openChatWidget()" class="btnStyle-yellow-border">Consult A Trademark Expert</a>
                    <div class="startingPoint">
                        <p>Packages start at <span>$35</span> - Click here to <a class="goDown" href="#packageSec"> View Packages</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include '../../includes/clients.php'; ?>

    <section class="tmProtection">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-xl-4">
                    <h2>At Trademark Assured, We Help You Apply For Your Trademark Globally!</h2>
                </div>
                <div class="col-xl-8 ps-xl-5">
                    <strong class="blink">Unlike most other agencies, our process for assigning serial numbers is much quicker. With Trademark Assured, it only takes 1-2 business days instead of the usual 8-13 days.</strong>
                    <p></p>
                    <p>With a team of experienced attorneys who have successfully protected thousands of trademarks in various jurisdictions including the US, UK, EU, and internationally. We understand the importance of protecting our clients' intellectual property rights, and we are committed to providing personalized and effective legal solutions to ensure that their trademarks are safeguarded against infringement and misuse.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="halfBlue whyRegisterSec">
        <div class="container">
            <div class="row">

                <div class="col-lg-4">
                    <div class="iconBox box">
                        <div class="icn">
                            <img src="assets/images/icons/uspto.webp" alt="">
                        </div>
                        <h3>USPTO Trademark</h3>
                        <p>Supercharge your brand's recognition in the USA with our top-tier US Trademark Registration Service. Let our skilled team handle the legalities, securing your intellectual property with USPTO.</p>
                        <a href="sequence/step1" class="btnStyle-yellow mt-3 me-3">Apply For Your Trademark</a>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="iconBox box">
                        <div class="icn">
                            <img src="assets/images/icons/cipo.webp" alt="">
                        </div>
                        <h3>CIPO <br> Trademark</h3>
                        <p>At Trademark Assured, our expert team ensures a smooth and efficient process, securing your intellectual property rights and empowering your business to thrive confidently in the Canadian market.</p>
                        <a href="javascript:void(0);" onclick="openChatWidget()" class="btnStyle-yellow mt-3 me-3">Consult A Trademark Expert</a>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="iconBox box">
                        <div class="icn">
                            <img src="assets/images/icons/global.webp" alt="">
                        </div>
                        <h3>International Trademark</h3>
                        <p>We handle the complexities of international trademark registration, leveraging the Madrid Protocol's streamlined process to protect your brand across multiple countries, while you focus on your business growth.</p>
                        <a href="javascript:void(0);" onclick="openChatWidget()" class="btnStyle-yellow mt-3 me-3">Consult A Trademark Expert</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="blueBg whyRegisterSec">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center mb-5">
                    <h2 class="text-white">Register your trademark in 3 simple steps</h2>
                    <p class="text-white">Our trademark registration process is designed to provide our clients with an efficient and effective means of protecting their intellectual property rights. At Trademark Assured, we provide assistance with the preparation and filing of the trademark application, and we offer ongoing monitoring services to ensure continued protection of the registered trademark. Our commitment to adherence to legal regulations and industry best practices ensures that our clients receive the highest level of service.</p>
                </div>
                <div class="col-lg-4">
                    <div class="iconBox box">
                        <div class="icn">
                            <span class="circle"></span>
                            <img src="assets/images/icons/1.webp" alt="">
                        </div>
                        <h3 class="w-100">Submit Your Trademark Information</h3>
                        <p>Submit your trademark information to us by answering few questions to initiate your trademark registration at USPTO.</p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="iconBox box">
                        <div class="icn">
                            <span class="circle"></span>
                            <img src="assets/images/icons/2.webp" alt="">
                        </div>
                        <h3>Service Selection & Payment</h3>
                        <p>After submitting relevant information, please select the appropriate service and complete your payment to proceed.</p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="iconBox box">
                        <div class="icn">
                            <span class="circle"></span>
                            <img src="assets/images/icons/3.webp" alt="">
                        </div>
                        <h3>Application Filing with USPTO</h3>
                        <p>After a thorough search on multiple databases to avoid possible infringement, we then file your trademark at USPTO.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include '../../includes/cta.php'; ?>


    <section class="packageSec" id="packageSec">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 style="margin-bottom: 3rem;">Cost-Effective Options to Safeguard Your Brand </h2>

                </div>
                <div class="col-lg-12">
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="home-tab-pane" role="tabpanel" aria-labelledby="home-tab" tabindex="0">
                            <div class="row">
                                <div class="col-lg-4 col-md-6">
                                    <div class="packgStyle">
                                        <h3>Basic</h3>
                                        <h2><del>$99</del> <i class="fas <?= $silverpriceUSCur ?>"></i><?= $silverpriceUS ?><span>+ USPTO Filing Fees</span></h2>
                                        <hr>
                                        <p>Secure your trademark registration serial number within just 8-10 days</p>
                                        <div class="featuredList">
                                            <ul class="listStyle">
                                                <li>
                                                    <p>Direct-hit Search</p>
                                                </li>
                                                <li>
                                                    <p>Federal E-Filing</p>
                                                </li>
                                                <li>
                                                    <p>Case Review</p>
                                                </li>
                                                <li>
                                                    <p>Case Preparation</p>
                                                </li>


                                            </ul>
                                        </div>
                                        <a href="sequence/step1" class="w-100 btnStyle">Get Started</a>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-6">
                                    <div class="packgStyle Recommended">
                                        <div class="tag">
                                            <p>Most Popular</p>
                                        </div>
                                        <h3>Deluxe</h3>
                                        <h2><del>$199</del> <i class="fas <?= $goldpriceUSCur ?>"></i><?= $goldpriceUS ?><span>+ USPTO Filing Fees</span></h2>
                                        <hr>
                                        <p>Secure your trademark registration serial number within just 24 to 48hrs</p>
                                        <div class="featuredList">
                                            <ul class="listStyle">
                                                <li>
                                                    <p>Direct-hit Search</p>
                                                </li>
                                                <li>
                                                    <p>Case Review</p>
                                                </li>
                                                <li>
                                                    <p>Refusal Risk Meter By Experts</p>
                                                </li>
                                                <li>
                                                    <p>Case Preparation</p>
                                                </li>
                                                <li>
                                                    <p>Case Filing</p>
                                                </li>
                                                <li>
                                                    <p>Trademark Alert</p>
                                                </li>
                                                <li>
                                                    <p>Trademark Secured</p>
                                                </li>
                                                <li>
                                                    <p>100% Satisfaction Guarantee</p>
                                                </li>
                                                <li>
                                                    <p>Trademark Monitoring</p>
                                                </li>
                                                <li>
                                                    <p>Complete Documentation</p>
                                                </li>
                                            </ul>
                                        </div>
                                        <a href="sequence/step1" class="w-100 btnStyle">Get Started</a>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-6">
                                    <div class="packgStyle">
                                        <div class="tag">
                                            <p>Recommended</p>
                                        </div>
                                        <h3>Premium</h3>
                                        <h2><del>$299</del> <i class="fas <?= $diamondpriceUSCur ?>"></i><?= $diamondpriceUS ?><span>+ USPTO Filing Fees</span></h2>
                                        <hr>
                                        <p>Secure your trademark registration serial number within just 24 to 48hrs</p>
                                        <div class="featuredList">
                                            <ul class="listStyle">
                                                <li>
                                                    <p>Direct-hit Search</p>
                                                </li>
                                                <li>
                                                    <p>Federal E-Filing</p>
                                                </li>
                                                <li>
                                                    <p>Case Review (Attorney Service)</p>
                                                </li>
                                                <li>
                                                    <p>Case Preparation</p>
                                                </li>
                                                <li>
                                                    <p>Case Filing By Attorney</p>
                                                </li>
                                                <li>
                                                    <p>Trademark Alert</p>
                                                </li>
                                                <li>
                                                    <p>Trademark Secured</p>
                                                </li>
                                                <li>
                                                    <p>Trademark Monitoring (For 12 Months)</p>
                                                </li>
                                                <li>
                                                    <p>Complete Documentation</p>
                                                </li>
                                                <li>
                                                    <p>Complimentary Cease & Desist letter</p>
                                                </li>
                                                <li>
                                                    <p>Complete Documentation</p>
                                                </li>
                                                <li>
                                                    <p>Dedicated Case Manager</p>
                                                </li>
                                                <li>
                                                    <p>100% Approval Guarantee</p>
                                                </li>
                                                <li>
                                                    <p>Fast Track 24 Hrs Service Included</p>
                                                </li>
                                            </ul>
                                        </div>
                                        <a href="sequence/step1" class="w-100 btnStyle">Get Started</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="screenBg servOfferSec">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center mb-5">
                    <h2 class="text-white">Services Offered by Trademark Assured</h2>
                    <p class="text-white">At Trademark Assured, our team of highly skilled professionals is equipped with the necessary knowledge and expertise to assist clients in navigating the complex legal requirements involved in trademark registration. Our services cover a wide range of aspects, including conducting trademark searches, filing trademark applications, responding to office actions, and managing trademark portfolios.</p>
                </div>
                <div class="col-lg-12">
                    <div class="tmServicesCarousel">
                        <div class="px-3">
                            <div class="iconBox servBox">
                                <h3>Trademark Registration</h3>
                                <p>Ready to secure the exclusive right to your brand and protect it from infringement? We offers a hassle-free way to register your trademark and gain legal protection against unauthorized use or imitation.</p>
                                <a href="../us-trademark-registration" class="linkStyle">Read More <i class="fal fa-long-arrow-right"></i></a>
                            </div>
                        </div>
                        <div class="px-3">
                            <div class="iconBox servBox">
                                <h3>Trademark Monitoring</h3>
                                <p>A reliable solution to monitor the use of your trademark across various platforms and jurisdictions ensuring your brand's integrity and value.</p>
                                <a href="../trademark-monitoring" class="linkStyle">Read More <i class="fal fa-long-arrow-right"></i></a>
                            </div>
                        </div>
                        <div class="px-3">
                            <div class="iconBox servBox">
                                <h3>Amazon Brand Registry</h3>
                                <p>Help you navigate the registration process and unlock the full benefits of the program, including increased brand visibility, and detecting and reporting infringement.</p>
                                <a href="../amazon-brand-registry-in-us" class="linkStyle">Read More <i class="fal fa-long-arrow-right"></i></a>
                            </div>
                        </div>
                        <div class="px-3">
                            <div class="iconBox servBox">
                                <h3>Comprehensive Trademark Search</h3>
                                <p>A thorough examination of databases to ensure your proposed trademark is unique, available for use, and not likely to cause confusion with existing trademarks.</p>
                                <a href="../comprehensive-trademark-search" class="linkStyle">Read More <i class="fal fa-long-arrow-right"></i></a>
                            </div>
                        </div>
                        <div class="px-3">
                            <div class="iconBox servBox">
                                <h3>Trademark Renewal</h3>
                                <p>We can help you stay on top of renewal deadlines & ensure your trademark remains up to date so that you can avoid the risk of losing your trademark rights & maintain your brand's legal protection.</p>
                                <a href="../trademark-renewal" class="linkStyle">Read More <i class="fal fa-long-arrow-right"></i></a>
                            </div>
                        </div>
                        <div class="px-3">
                            <div class="iconBox servBox">
                                <h3>Office Action Response</h3>
                                <p>If your trademark is facing opposition, we can help you craft a strong and persuasive response to any opposition, leveraging our legal expertise and experience to help you secure your trademark.</p>
                                <a href="office-action-response" class="linkStyle">Read More <i class="fal fa-long-arrow-right"></i></a>
                            </div>
                        </div>
                        <div class="px-3">
                            <div class="iconBox servBox">
                                <h3>Cease & Desist Letter</h3>
                                <p>If you've identified unauthorized use of your trademark, we can help you craft a clear and effective letter that demands the immediate cessation of any infringing activity.</p>
                                <a href="../cease-desist-letters" class="linkStyle">Read More <i class="fal fa-long-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="pattern-bg chooseTmAssure">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center mb-5">
                    <h2>Why Choose Trademark Assured?</h2>
                </div>
                <div class="col-xl-9">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="iconBox simple">
                                <div class="icn">
                                    <span class="circle"></span>
                                    <img src="assets/images/icons/4.webp" alt="">
                                </div>
                                <h3>Exclusive Fast Track 24 Hrs Service</h3>
                                <p>At Trademark Assured, we offer top-notch fast track 24 hrs service for your urgent business needs.</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="iconBox simple">
                                <div class="icn">
                                    <span class="circle"></span>
                                    <img src="assets/images/icons/5.webp" alt="">
                                </div>
                                <h3>Comprehensive Trademark Search</h3>
                                <p>We search international, domestic, state and domain name databases to identify potential conflicts.</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="iconBox simple">
                                <div class="icn">
                                    <span class="circle"></span>
                                    <img src="assets/images/icons/7.webp" alt="">
                                </div>
                                <h3>Affordable Pricing</h3>
                                <p>We offer affordable pricing and a transparent fee structure for our trademark registration & search services. </p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="iconBox simple">
                                <div class="icn">
                                    <span class="circle"></span>
                                    <img src="assets/images/icons/9.webp" alt="">
                                </div>
                                <h3>Experienced Attorneys</h3>
                                <p>We have a team of experienced intellectual property attorneys to help you achieve your business goals.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3">
                    <div class="stateBoxRow">
                        <div class="statsBox">
                            <h2>1500+</h2>
                            <p>Trademarks Registered</p>
                        </div>
                        <div class="statsBox">
                            <h2>4632+</h2>
                            <p>Applications in process</p>
                        </div>
                        <div class="statsBox">
                            <h2>100+</h2>
                            <p>Nationalities of Our Clients</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="testimonialSec">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <div class="testimonialCarousel">
                        <div>
                            <div class="testimonialItem">
                                <div class="img">
                                    <img src="assets/images/testimonial/david-lee.webp" alt="" class="rounded">
                                    <h5>David Lee</h5>
                                    <span>Bode Ltd</span>
                                </div>
                                <div class="content">
                                    <h2>See What Our Clients Have to Say</h2>
                                    <p>I needed to dissolve my company and didn't know where to start. Trademark Assured provided me with step-by-step guidance and made the entire process stress-free. Their team was professional and responsive to all of my questions. I highly recommend their services for anyone in need of company dissolution assistance. </p>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div class="testimonialItem">
                                <div class="img">
                                    <img src="assets/images/testimonial/emily-chen.webp" alt="" class="rounded">
                                    <h5>Emily Chen</h5>
                                    <span>Sells on Amazon</span>
                                </div>
                                <div class="content">
                                    <h2>See What Our Clients Have to Say</h2>
                                    <p>Trademark Assured helped me navigate the complicated process of registering my brand with the Amazon Brand Registry in the US. Their team was knowledgeable and provided valuable insights that I wouldn't have known otherwise. I highly recommend their services for anyone looking to protect their brand on Amazon. </p>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div class="testimonialItem">
                                <div class="img">
                                    <img src="assets/images/testimonial/michael-johnson.webp" alt="" class="rounded">
                                    <h5>Michael Johnson</h5>
                                    <span>Greenfelder LLC</span>
                                </div>
                                <div class="content">
                                    <h2>See What Our Clients Have to Say</h2>
                                    <p>I received an office action notice and didn't know what to do. Thankfully, I reached out to Trademark Assured and they provided me with a comprehensive response that addressed all of the issues. Their team was extremely helpful and I would recommend their services to anyone in need of an office action response. </p>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div class="testimonialItem">
                                <div class="img">
                                    <img src="assets/images/testimonial/jane-smith.webp" alt="" class="rounded">
                                    <h5>Jane Smith</h5>
                                    <span>Leuschke Ltd</span>
                                </div>
                                <div class="content">
                                    <h2>See What Our Clients Have to Say</h2>
                                    <p>I was worried about renewing my trademark, but Trademark Assured took care of everything. Their team was professional, and knowledgeable, and made the entire process smooth and seamless. I couldn't be happier with their service and highly recommend them.</p>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div class="testimonialItem">
                                <div class="img">
                                    <img src="assets/images/testimonial/drewd-wilkins.webp" alt="" class="rounded">
                                    <h5>Drew D. Wilkins</h5>
                                    <span>Owns a Flower Shop</span>
                                </div>
                                <div class="content">
                                    <h2>See What Our Clients Have to Say</h2>
                                    <p>Trademark Assured made the process of registering my trademark so easy and stress-free. They were extremely helpful throughout the process and their team was very responsive to all of my questions. I highly recommend their services to anyone looking to protect their brand. </p>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div class="testimonialItem">
                                <div class="img">
                                    <img src="assets/images/testimonial/sarah-thompson.webp" alt="" class="rounded">
                                    <h5>Sarah Thompson</h5>
                                    <span>Owner of Delta Diaries</span>
                                </div>
                                <div class="content">
                                    <h2>See What Our Clients Have to Say</h2>
                                    <p>I was hesitant to register my trademark at first, but working with Trademark Assured was a game changer. Their team walked me through every step of the process, provided valuable insights, and made everything easy to understand. I'm glad I chose them and highly recommend their services. </p>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div class="testimonialItem">
                                <div class="img">
                                    <img src="assets/images/testimonial/alex-rodriguez.webp" alt="" class="rounded">
                                    <h5>Alex Rodriguez</h5>
                                    <span>Co-founder - Ring Dynamics</span>
                                </div>
                                <div class="content">
                                    <h2>See What Our Clients Have to Say</h2>
                                    <p>I recently registered my trademark with the help of Trademark Assured, and I'm thrilled with the outcome. Their team was knowledgeable, and professional, and provided excellent guidance throughout the entire process. They made sure all of my questions were answered and helped me feel confident in my decision to register my trademark. I highly recommend their services for anyone looking to protect their brand.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php include '../../includes/faq.php'; ?>
    <?php include '../../includes/cta.php'; ?>
    <footer>
        <div class="container-fluid">
            <div class="row align-items-center ">
                <div class="col-xl-3 col-lg-3">
                    <a href="../../"><img src="assets/images/footer-logo.webp" alt=""></a>
                </div>
                <div class="col-xl-9 col-lg-9">
                    <ul class="contInfo">
                        <li><a href="#"><i class="fal fa-map-marker-alt"></i>
                                <?= $address ?>
                            </a></li>
                        <li><a href="tel:<?= $phone ?>"><i class="fal fa-phone-alt"></i>
                                <?= $phone ?>
                            </a></li>
                        <li><a href="mailto:<?= $email ?>"><i class="fal fa-envelope"></i>
                                <?= $email ?>
                            </a></li>
                    </ul>
                </div>
            </div>
        </div>
        </div>
        <div class="copyRight">
            <div class="container-fluid">
                <div class="row align-items-center justify-content-between">
                    <div class="col-md-6 col-sm-12">
                        <p>Copyright © 2009-2023 Trademark Assured. All Rights Reserved.</p>
                    </div>

                    <div class="col-md-4 col-sm-12">
                        <ul class="links">
                            <li><a href="privacy-policy">Privacy Policy</a></li>
                            <li> | </li>
                            <li><a href="terms-and-conditions">Terms & Conditions</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>



    <?php include '../../includes/script.php'; ?>